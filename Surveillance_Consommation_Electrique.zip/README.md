# Surveillance de la Consommation Électrique

Ce projet permet de surveiller la consommation électrique en temps réel à l'aide d'un **ESP8266** et d'un **capteur ZMPT101B**. Il envoie les données à un **serveur Flask**, qui peut être visualisé via une interface web.

## 📜 Installation

### 1. Serveur Flask (Python)
Installez les dépendances :
```sh
pip install flask
```
Lancez le serveur :
```sh
python server.py
```

### 2. Code ESP8266 (Arduino)
- Remplacez `VOTRE_SSID` et `VOTRE_MOT_DE_PASSE` par ceux de votre Wi-Fi.
- Flashez le code `esp8266_zmpt101b.ino` sur l'ESP8266.

### 3. Interface Web (React.js)
Ajoutez un dashboard React.js pour visualiser les données.

## 📡 Fonctionnement
- L’ESP8266 lit la tension secteur via **ZMPT101B** et envoie les données à Flask.
- Flask stocke et expose ces données via une API JSON.
- Une interface web peut afficher la consommation en temps réel.

🚀 *Bon développement !*

